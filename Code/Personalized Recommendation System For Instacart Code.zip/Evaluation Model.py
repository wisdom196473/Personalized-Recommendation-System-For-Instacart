# Team 4
## Author:

# Yu-Chih (Wisdom) Chen

# Jessy Hu

# Boya Zeng

# Yuqing Wu

# Date: 02/15/2024

import pandas as pd
import warnings
warnings.filterwarnings('ignore')

## Baby Formula Records

df = pd.read_csv("baby_formula_df.csv")
print(df.shape)

### 1233644 records

## Mean Reciprocal Rank (MRR)
# MRR is a statistic measure for evaluating any process that produces a list of
# possible responses to a sample of queries, ordered by probability of correctness.
# The MRR is the average of the reciprocal ranks of results for a sample of queries Q:

# Load the customer recommendations data
df_customer = pd.read_csv('customer_recommendations.csv')

# Extract the rank as an integer from the 'Recommendation Rank' column
df_customer['Rank'] = df_customer['Recommendation Rank'].str.extract('(\d+)').astype(int)

# Calculate the reciprocal rank for each product ID
df_customer['Reciprocal Rank'] = 1 / df_customer['Rank']

# Calculate the MRR for each product ID
mrr_per_product = round(df_customer.groupby('ID')['Reciprocal Rank'].mean().reset_index(), 2)

# Store the results in a DataFrame
mrr_per_product_df = pd.DataFrame(mrr_per_product)

# Rename columns for clarity
mrr_per_product_df.columns = ['Product ID', 'Mean Reciprocal Rank (MRR)']


# Print the MRR for each product ID
print(mrr_per_product)
